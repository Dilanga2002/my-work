/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package waterBil;

/**
 *
 * @author User
 */
public class waterBill {
    
    
    private double prereading;
    private double curreading;
    private double consummsion;
    private double charge;
    
    
    public waterBill(double p,double c){
        this.prereading = p;
        this.curreading = c;
    }
    
    public double calConsummsion(){
        consummsion=curreading-prereading;
        return consummsion;
    }
    
    public double calWaterCharge(double n,double ch, double s){
        if(charge<=5){
            charge = n*ch*s;
        }
        else if(charge<=10){
        charge = n*ch*s;
    }else{
             charge = n*ch*s;
        }
        return charge;
    }
}
