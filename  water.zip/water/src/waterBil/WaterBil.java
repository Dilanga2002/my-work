/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package waterBil;

/**
 *
 * @author User
 */
public class WaterBil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        waterBill ob = new waterBill(30,50);
        
        System.out.println(ob.calConsummsion());
        System.out.println(ob.calWaterCharge(5, 12, 50));
    }
    
}
