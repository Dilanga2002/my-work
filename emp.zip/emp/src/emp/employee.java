/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package emp;

/**
 *
 * @author User
 */
public class employee {
    
    private int empnumber;
    private String empname;
    private String address;
    private int contactdetails;
    private double basicsalary;
    
    
    public employee(int nu,String na, String a, int c,double b) {
        this.empnumber = nu;
        this.empname = na;
        this.address = a;
        this.contactdetails = c;
        this.basicsalary = b;
    }
    public double salaryIncrement(double increment){
        basicsalary = basicsalary +increment;
        return basicsalary;
    }
    
    public void display(){
        System.out.println("number"+empnumber);
        System.out.println("name"+empname);
        System.out.println("address"+address);
        System.out.println("contact"+contactdetails);
        System.out.println("salary"+basicsalary);
    }
    
}
