/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package emp;

/**
 *
 * @author User
 */
public class Emp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        employee ob = new employee(1,"kamal","gam",76,50000);
        
       ob.display();
      System.out.println(ob.salaryIncrement(5000)); 
    }
    
}
